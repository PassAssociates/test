<?php
echo"<h1 style='text-align: center'>COMMING SOON</h1>";