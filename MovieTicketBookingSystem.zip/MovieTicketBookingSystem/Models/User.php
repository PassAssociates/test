<?php
namespace Models;

use Classes\Model;

class User extends Model
{
    protected $table = 'users';
    protected $fillable = ['first_name', 'last_name', 'email', 'mobile', 'password', 'role_id'];
}