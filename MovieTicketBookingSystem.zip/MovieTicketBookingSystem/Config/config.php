<?php
define('BASE_URL','http://localhost:8000');
define('DB_HOST','localhost');
define('DB_NAME','test');
define('DB_USER','root');
define('DB_PASS','');