<?php
namespace Controllers;

use Models\User;
use Request\Request;
class UserController
{
    public function index(Request $request){
        $data = User::where('role_id','=',1)
            ->where('first_name','=','sub')
            ->get();
        echo '<pre>';
        print_r($data);
    }
}