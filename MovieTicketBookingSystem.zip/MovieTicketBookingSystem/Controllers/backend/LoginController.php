<?php


namespace Controllers\Backend;


use Request\Request;

class LoginController
{
    public function index(){
        return export('backend/authentication/login','');
    }

    public function login(Request $request){
        print_r($request->getBody());
    }
}