<?php
Route::get('/',function (Request $request){
    export('welcome',[]);
});
Route::get('/admin', 'Backend\LoginController@index');
Route::post('/admin', 'Backend\LoginController@login');


Route::get('/test','UserController@index');


